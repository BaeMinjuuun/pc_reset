const MainPage = () => {
  return (
    <div>
      <div>메인 페이지(추후 구현 예정)</div>
    </div>
  );
};

export default MainPage;
