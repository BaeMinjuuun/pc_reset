# TEST

# 서버접속: devel01@himsr2.iptime.org -p 40822

# 파일경로: home/devel01/bmj/prem/web/emulator/agent_server

1. 해당 경로의 batch.js 파일 수정(주석 참조)
   a. 필요시 파일 추가해서 실행(테스트 병렬실행시)
2. node batch.js 명령어 입력으로 실행됨

% 현재 실행중인 batch.js 파일이 있다면 확인 후 실행할것.
