module.exports = {
  "AGENT_URL": "http://localhost:8150",
  "TIME_OVER": 600,
  "RESET_COUNT": 3,
  "UDP_PORT": 31000,
  "UDP_HOST": "localhost",
  "MODULE_BATCH_SIZE": 1000,
  "TEST_URL": "http://10.81.234.7:8130"
};