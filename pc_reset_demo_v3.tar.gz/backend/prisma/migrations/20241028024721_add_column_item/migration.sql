-- AlterTable
ALTER TABLE `ChangesLog` ADD COLUMN `item` VARCHAR(100) NULL;
