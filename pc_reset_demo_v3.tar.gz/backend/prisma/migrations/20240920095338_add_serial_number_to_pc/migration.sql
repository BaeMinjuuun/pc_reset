-- AlterTable
ALTER TABLE `Pc` ADD COLUMN `serial_number` VARCHAR(100) NULL;
